﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodingTests.Models
{
	public class EmployeeDetails
	{
		public string Firstname { get; set; }
		public string Lastname { get; set; }
	}
}
